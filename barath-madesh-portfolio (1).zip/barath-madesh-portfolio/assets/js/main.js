const header = document.getElementById('header');
const navMenu = document.getElementById('nav-menu');
const navToggle = document.getElementById('nav-toggle');
const scrollTop = document.getElementById('scroll-top');
const navLinks = [...document.querySelectorAll('.nav__link')];

navToggle.addEventListener('click', () => {
  const isOpen = navMenu.classList.toggle('open');
  navToggle.setAttribute('aria-expanded', String(isOpen));
  navToggle.setAttribute('aria-label', isOpen ? 'Close navigation' : 'Open navigation');
  navToggle.innerHTML = isOpen ? '<i class="ri-close-line"></i>' : '<i class="ri-menu-3-line"></i>';
});

navLinks.forEach(link => link.addEventListener('click', () => {
  navMenu.classList.remove('open');
  navToggle.setAttribute('aria-expanded', 'false');
  navToggle.setAttribute('aria-label', 'Open navigation');
  navToggle.innerHTML = '<i class="ri-menu-3-line"></i>';
}));

function updateOnScroll() {
  const y = window.scrollY;
  header.classList.toggle('scrolled', y > 20);
  scrollTop.classList.toggle('show', y > 450);
  const sections = [...document.querySelectorAll('main section[id]')];
  let current = '';
  sections.forEach(section => {
    if (y >= section.offsetTop - 150) current = section.id;
  });
  navLinks.forEach(link => {
    link.classList.toggle('active', link.getAttribute('href') === `#${current}`);
  });
}
window.addEventListener('scroll', updateOnScroll, { passive: true });
updateOnScroll();
document.getElementById('year').textContent = new Date().getFullYear();

// Respect reduced-motion preferences and reveal sections as they enter the viewport.
if ('IntersectionObserver' in window && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('in-view');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.08 });
  document.querySelectorAll('.section-heading, .about__statement, .about__details, .stat, .timeline-item, .skill-card, .project-card').forEach(el => {
    el.classList.add('reveal');
    observer.observe(el);
  });
}
