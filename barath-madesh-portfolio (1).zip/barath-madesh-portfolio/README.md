# Barath Madesh — Personal Portfolio

A responsive static portfolio built from the supplied Patrick responsive portfolio starter design and customized using the provided resume.

## Run locally
Open `index.html` in a browser, or run a local static server from this folder:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Before publishing
- Confirm the LinkedIn profile URL and replace the generic LinkedIn link in `index.html`.
- Add your GitHub profile URL and project repository/demo links where available.
- Confirm that `https://barathmadesh.com` points to this portfolio before sharing it publicly.
- Replace the abstract CSS hero artwork with a professional portrait if you prefer a personal photo.

This site uses Google Fonts and Remix Icon via CDN; those resources require an internet connection. The site itself is plain HTML, CSS, and JavaScript and does not require a build step.
